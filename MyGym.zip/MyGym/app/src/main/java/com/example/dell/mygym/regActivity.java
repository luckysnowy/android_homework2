package com.example.dell.mygym;
import android.app.Dialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.view.View.OnClickListener;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.widget.EditText;
import android.widget.Toast;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;

import java.util.ArrayList;
import java.util.List;
public class regActivity extends AppCompatActivity {
    private Button rl;
    private Button regs;
    EditText username, password,cpassword;
    Dialog dialog;
    Handler handler;
    static int LOGIN_FAILED = 0;
    static int LOGIN_SUCCEEDED = 1;
    static int REGISTER_FAILED = 2;
    static int REGISTER_SUCCEEDED = 3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.reg);
        rl=(Button) findViewById(R.id.retu);
        regs=(Button) findViewById(R.id.rega);
        password = (EditText)findViewById(R.id.pass0);
        cpassword= (EditText)findViewById(R.id.pass1);
        username = (EditText)findViewById(R.id.account1);
        rl.setOnClickListener(new OnClickListener(){
            @Override
            public  void onClick(View v2){
                Intent intent=new Intent(regActivity.this,loginActivity.class);
                startActivity(intent);
            }
        });
       regs.setOnClickListener(new OnClickListener(){
           @Override
           public  void onClick(View v){
               if(checkEdit()) {//检查注册信息
                   if (username.getText().toString().equals(""))
                       Toast.makeText(regActivity.this, "请输入账号", Toast.LENGTH_SHORT).show();
                   else {
                       //启动登录Thread
                       dialog = new Dialog(regActivity.this);
                       dialog.setTitle("正在注册，请稍后...");
                       dialog.setCancelable(false);
                       dialog.show();
                       new RegisterPostThread(username.getText().toString(), password.getText().toString()).start();
                   }
               }

           }
       });
        //Handle,Msg返回成功信息，跳转到其他Activity
        handler = new Handler() {
            public void handleMessage(Message msg) {
                super.handleMessage(msg);
                dialog.dismiss();
                if (msg.what == 222) {  // 处理发送线程传回的消息
                    if(msg.obj.toString().equals("SUCCEEDED")){
                        Toast.makeText(regActivity.this, "注册成功！", Toast.LENGTH_SHORT).show();
                    }else{
                        Toast.makeText(regActivity.this, "账号已被注册，注册失败", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        };
    }
    //注册Thread调用RegisterPostService，返回Msg
    public class RegisterPostThread extends Thread {
        public String  username, password;

        public RegisterPostThread(String username, String password) {
            this.username = username;
            this.password = password;
        }

        @Override
        public void run() {
            // Sevice传回int
            int responseInt = 0;
            if(!username.equals("")) {
                // 要发送的数据
                List<NameValuePair> params = new ArrayList<NameValuePair>();
                params.add(new BasicNameValuePair("username", username));
                params.add(new BasicNameValuePair("password", password));
                // 发送数据，获取对象
                responseInt = RegisterPostService.send(params);
                Log.i("tag", "RegisterActivity: responseInt = " + responseInt);
                // 准备发送消息
                Message msg = handler.obtainMessage();
                // 设置消息默认值
                msg.what = 222;
                // 服务器返回信息的判断和处理
                if(responseInt == REGISTER_FAILED) {
                    msg.obj = "FAILED";
                }else if(responseInt == REGISTER_SUCCEEDED) {
                    msg.obj = "SUCCEEDED";
                }
                handler.sendMessage(msg);
            }
        }
    }

    //检查注册信息
    public boolean checkEdit(){
        if(username.getText().toString().equals("")){
            Toast.makeText(regActivity.this, "账户不能为空", Toast.LENGTH_SHORT).show();
            return false;
        }
        if(password.getText().toString().equals("")){
            Toast.makeText(regActivity.this, "密码不能为空", Toast.LENGTH_SHORT).show();
            return false;
        }
        if(!cpassword.getText().toString().equals(password.getText().toString())){
            Toast.makeText(regActivity.this, "两次输入的密码不同", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }

}
