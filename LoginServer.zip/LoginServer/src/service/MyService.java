package service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import db.DBManager;

public class MyService {
	static PreparedStatement preparedStatement = null;    
    static ResultSet resultSet = null;    
    static int updateRowCnt = 0;  
    static int LOGIN_FAILED = 0;  
    static int LOGIN_SUCCEEDED = 1;  
    static int REGISTER_FAILED = 2;  
    static int REGISTER_SUCCEEDED = 3;  
        
    public static int login(String username, String password) {    
        int result = LOGIN_FAILED;    
        resultSet = null;  
        // ִ�� SQL ��ѯ���    
        String sql = "select * from android where username='" + username +"'";    
        try {       
            Connection con = DBManager.getConnection();    
            preparedStatement = con.prepareStatement(sql);    
            try{    
                resultSet = preparedStatement.executeQuery();    
                // ��ѯ���    
                if(resultSet.next()){      
                    if(resultSet.getString("password").equals(password)){  
                        result = LOGIN_SUCCEEDED;  
                        System.out.println("username:" + username  
                            + " username:" + resultSet.getString("username")  
                            + " --login");  
                    }  
                }    
                preparedStatement.close();    
                con.close();    
            }catch(Exception e){    
                e.printStackTrace();    
            }    
        }catch(Exception e){    
            e.printStackTrace();    
        }    
        System.out.println("login service result:" + result);  
        return result;    
    }    
      
    public static int register(String username, String password) {    
        int result = REGISTER_FAILED;    
        updateRowCnt = 0;  
        // ִ�� SQL �������    
        String sql = "insert into android(`username`,`password`) values ('" + username + "', '" + password + "')";  
        try {       
            Connection con = DBManager.getConnection();    
            preparedStatement = con.prepareStatement(sql);    
            try{    
                updateRowCnt = preparedStatement.executeUpdate();    
                // ������    
                if(updateRowCnt != 0){      
                        result = REGISTER_SUCCEEDED;  
                        System.out.println(" username:" + resultSet.getString("username")+ " --register");  
                }    
                preparedStatement.close();    
                con.close();    
            }catch(Exception e){    
                e.printStackTrace();    
            }    
        }catch(Exception e){    
            e.printStackTrace();    
        }    
        System.out.println("register service result:" + result);  
        return result;    
    }  
}
